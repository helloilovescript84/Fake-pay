package com.example.fakepaylocal;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class FakePayLocalClient implements ClientModInitializer {
    private static final DecimalFormat MONEY_FORMAT = new DecimalFormat(
            "#,##0.##",
            DecimalFormatSymbols.getInstance(Locale.US)
    );

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("fakepay")
                        .then(ClientCommandManager.argument("player", StringArgumentType.word())
                                .then(ClientCommandManager.argument("amount", DoubleArgumentType.doubleArg(0.01, 1.0e15))
                                        .executes(context -> {
                                            String player = StringArgumentType.getString(context, "player");
                                            double amount = DoubleArgumentType.getDouble(context, "amount");
                                            context.getSource().sendFeedback(buildPreview(player, amount));
                                            return 1;
                                        })))));
    }

    private static Text buildPreview(String player, double amount) {
        return Text.empty()
                .append(Text.literal("[SIMULATED] ").formatted(Formatting.GOLD, Formatting.BOLD))
                .append(Text.literal("You paid ").formatted(Formatting.GRAY))
                .append(Text.literal("$" + MONEY_FORMAT.format(amount)).formatted(Formatting.GREEN, Formatting.BOLD))
                .append(Text.literal(" to ").formatted(Formatting.GRAY))
                .append(Text.literal(player).formatted(Formatting.YELLOW))
                .append(Text.literal(" (local preview only; no money transferred)").formatted(Formatting.DARK_GRAY));
    }
}
