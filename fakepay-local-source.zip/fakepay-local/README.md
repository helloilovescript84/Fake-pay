# FakePay Local Simulator

A client-only Fabric mod for Minecraft Java 1.21.11. It prints a locally rendered payment-style preview in your own chat. Every preview has a prominent `[SIMULATED]` label and an explicit note that no money was transferred.

## What it does

- Adds `/fakepay <player> <amount>` as a client-side command.
- Formats the amount with comma grouping and up to two decimal places.
- Displays the preview only in the local client chat.
- Does not send a `/pay` command, chat packet, transaction, or server message.
- Does not imitate an authentic DonutSMP success notification.

## Prerequisites

- Minecraft Java Edition 1.21.11
- Fabric Loader 0.19.5 or newer compatible with 1.21.11
- Fabric API 0.141.6+1.21.11
- Java 21 JDK
- Gradle 9.2 or newer (or a compatible Gradle installation)

## Build

From this directory, run:

```bash
gradle build
```

The compiled mod will be in `build/libs/fakepay-local-1.0.0.jar`.

## Install and use

1. Install Fabric for Minecraft 1.21.11.
2. Put the matching Fabric API jar in your `mods` folder.
3. Build this project and put `build/libs/fakepay-local-1.0.0.jar` in the same `mods` folder.
4. Launch the Fabric 1.21.11 profile.
5. Run `/fakepay Steve 2500000` in chat to display a local preview.

The preview is client-side only. Other players cannot see it, and it cannot change any DonutSMP balance.
